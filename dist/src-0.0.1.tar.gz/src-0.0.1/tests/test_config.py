
def test_generic():
    a=3
    b=3
    assert a==b

